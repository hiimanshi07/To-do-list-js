const box = document.getElementById("box");
const list = document.getElementById("list");

box.addEventListener("keypress", function onEvent(event) {
  //event listner on box element
  if (event.key === "Enter") {
    //if key === enter
    document.getElementById("btn").click();
    //get the output eith enter key instead of clicking button
  }
});
const editIcon = document.getElementById("editIcon");
const editableInput = document.getElementById("editableInput");

editIcon.addEventListener("click", function () {
  // Enable the input field and make it editable when the icon is clicked
  editableInput.removeAttribute("disabled");
  editableInput.focus();
});

editableInput.addEventListener("blur", function () {
  // Save the changes and disable the input when it loses focus
  editableInput.setAttribute("disabled", "true");
  // You can save the changes here, for example, by sending the updated text to the server or storing it in a variable.
});

function addTask() {
  if (box.value === "") {
    alert("Please add your task..");
  } else {
    let li = document.createElement("li"); //creating html element
    li.innerHTML = box.value; //TEXT which added in input box
    list.appendChild(li); //DISPLAY IN LIST CONTAINER

    let span = document.createElement("span");
    span.innerHTML = "\u00d7";
    li.appendChild(span);

    let span1 = document.createElement("span");
    span1.innerHTML = '<i class="fas fa-pen-square"></i>';

    li.appendChild(span1);
    box.value = "";

    paragraph.style.backgroundcolor = "#dddbdb";

    const paragraph = document.getElementById("box");
    const btn = document.getElementById("btn");

    btn.addEventListener("click", function () {
      paragraph.contentEditable = true;
    });
    //   span1.addEventListener("click", function () {
    //     li.style.display = "none"; // Hide the task text
    //     const editInput = document.getElementById("list");
    //     editInput.style.display = "inline"; // Show the input field
    //     editInput.value = li.textContent.trim(); // Set input value to the task text
    //     editInput.focus();
    //   });

    //   // Add an event listener for input field to save changes
    //   editInput.addEventListener("blur", function () {
    //     li.style.display = "block"; // Show the task text
    //     editInput.style.display = "none"; // Hide the input field
    //     li.textContent = editInput.value; // Update the task text with input value
    //   }); //after adding one value the box will be empty
    // }
  }
  list.addEventListener("click", function () {
    if (e.target.tagName === "LI") {
      //if tagname=li toggle with
      e.target.classList.toggle("checked");
    } else if (e.target.tagName === "SPAN") {
      e.target.parentElement.remove();
      //   list.remove();
    }
  });

  function clearErrors() {
    var errors = document.getElementsByClassName("ferror");
    for (let item of errors) {
      item.innerHTML = "";
    }
  }

  function seterror(id, error) {
    element = document.getElementById(id);
    element.getElementsByClassName("ferror")[0].innerHTML = error;
  }
}
