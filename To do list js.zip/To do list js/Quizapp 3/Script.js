const questions = [
  {
    question: "Where is India's First nuclear centre?",
    answers: [
      { text: "Tarapur", correct: true },
      { text: "Jaipur", correct: false },
      { text: "Kanpur", correct: false },
      { text: "Raipur", correct: false },
    ],
  },
  {
    question: " Name of first woman governor of India ?",
    answers: [
      { text: "Sushma Swaraj", correct: false },
      { text: "Indira Gandhi", correct: false },
      { text: "Sarojini Naidu", correct: true },
      { text: "Rani Lakshmibai", correct: false },
    ],
  },
  {
    question: "The percentage of earth's water found in the oceans is ______.",
    answers: [
      { text: "94 per cent", correct: false },
      { text: "97.3 per cent", correct: true },
      { text: "90.2 per cent", correct: false },
      { text: "92.2 per cent", correct: false },
    ],
  },
  {
    question:
      "The tenth day after ______ Navratri is celebrated as Dussehra or Vijayadashami.",
    answers: [
      { text: "Sharad", correct: true },
      { text: "Ashadha", correct: false },
      { text: "Chaitra", correct: false },
      { text: "Aaso", correct: false },
    ],
  },
  {
    question: "Which of the following is a tributary of the river Ganga?",
    answers: [
      { text: "Sabarmati", correct: false },
      { text: "Mahi", correct: false },
      { text: "Ghaghra", correct: true },
      { text: "Bhima", correct: false },
    ],
  },
];

const questionElement = document.getElementById("que");
const ansbtn = document.getElementById("ans_btn");
const nextbtn = document.getElementById("next_btn");
const feedbackElement = document.getElementById("feedback");
//created constant elements  
let currentqueIndex = 0;
let score = 0;
function startQuiz() {
  resetState();
  currentqueIndex = 0;
  score = 0;
  nextbtn.innerHTML = "Next";
  showQuestion();
}
//made  function to start quiz again called
// resetstate gave next name to the button
function showQuestion() {
  resetState();
  feedbackElement.style.display = "none";

  //when the question is displayed the feedback element will be hided
  let currentQuestion = questions[currentqueIndex];
  let questionNo = currentqueIndex + 1;
  //making constants for question 
  
  questionElement.innerHTML = questionNo + "." + currentQuestion.question;
  
  currentQuestion.answers.forEach((answer) => {
    const button = document.createElement("button");
    button.innerHTML = answer.text; //from  above declared object questions answers
    button.classList.add("btn");//made btn class in js
    ansbtn.appendChild(button);//appended ansbtn to constant button
    if (answer.correct) {
      button.dataset.correct = answer.correct;   //if answer is correct 
    }
    button.addEventListener("click", selectAnswer);
    //when button clicked selectAnswer sunction will be called
  });
}
function resetState() {
  nextbtn.style.display = "none";//when is is reset the next button will be invisible
  while (ansbtn.firstChild) { 
    ansbtn.removeChild(ansbtn.firstChild);//while loop will remove all the child elementgs from ansbtn if it have
  }
}
 
function selectAnswer(e) {
  const selectedBtn = e.target;
  const isCorrect = selectedBtn.dataset.correct === "true";
  feedbackElement.style.display = "block";//when answer clicked the feedback  will be visible 
  if (isCorrect) {
    selectedBtn.classList.add("correct");
    feedbackElement.textContent = "Correct answer!";
    feedbackElement.style.color = "green";
    score++;
  } else {
    selectedBtn.classList.add("incorrect");
    feedbackElement.textContent = "*Wrong answer!!";
    feedbackElement.style.color = "red";
  }
  Array.from(ansbtn.children).forEach((button) => {
    if (button.dataset.correct === "true") {
      button.classList.add("correct");
    }
    button.disabled = true;
  });
  nextbtn.style.display = "block";
}

function showScore(){
  resetState();
  questionElement.innerHTML = `You Scored ${score} out of ${questions.length}!`;
  questionElement.style.textAlign="center";
  nextbtn.innerHTML="Play again";
  nextbtn.style.height = "50px";
  nextbtn.style.width = "150px";
  nextbtn.style.textAlign = "center";
  nextbtn.style.marginLeft = "200px"
  nextbtn.style.display="block";
  feedbackElement.style.display = "none";//to making feedback element invisible
}
function handlenextbtn() {                          
  currentqueIndex++;
  resetState();                                                            
  if (currentqueIndex < questions.length) { //if currentqueIndex is less than questions.length then it will call the showQuestion function
    showQuestion();//declaring the showQuestion function to diaplay the function                                                            
  } else {
    showScore(); //showScore to display the score                                                                   
  }
}
nextbtn.addEventListener("click", () => {//if currentqueIndex is less than questions.length then it will call the showQuestion function
  if (currentqueIndex < questions.length) {
    handlenextbtn();
  } else {
    startQuiz();
  }
});
startQuiz();
















 

















