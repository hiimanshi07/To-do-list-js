//define variables
let renderData =  document.querySelector(".renderData");//query selector when select element using css selector or selects the first element thar matches specified selectors
//if targeting class then .renderData for id #renderData
let renderCartData =  document.querySelector(".renderCartData");
let dynamic_count =  document.querySelector(".dynamic-count");
let arr=[];
let icon = document.getElementById("icon")
// const cart = document.getElementById("cat-icon");
async function getData(){ //async used when task can  take some time to execute
    const response= await fetch("https://fakestoreapi.com/products");//wait till data fetched from API
    const data = await response.json();//wait till data converts into json
    // console.log(data)
    
    data.map((ele) => {  //map  function to iretate through each element 
        let productMainDiv = document.createElement("div");
        let createImgEle = document.createElement("img"); 
        let createTitle =document.createElement("p");
        let createPriceEle = document.createElement("p");
        let btnEle = document.createElement("button");
        let btnText = document.createTextNode("Add to cart");
        let createPriceText = document.createTextNode(`price : $${ele.price}`);
        let createTextTitle = document.createTextNode(ele.title);
        
    
    
       
        createImgEle.setAttribute("src",ele.image);
        createImgEle.setAttribute("class","myImage");
        productMainDiv.setAttribute("class","box-main");
    
        createTitle.appendChild(createTextTitle);
        createPriceEle.appendChild(createPriceText);
        btnEle.appendChild(btnText);
    
        productMainDiv.appendChild(createImgEle);//appending to display the image
        productMainDiv.appendChild(createTitle);
        productMainDiv.appendChild(btnEle);
        productMainDiv.appendChild(createPriceEle);                  
        renderData.appendChild(productMainDiv);
        btnEle.addEventListener("click",() => addToCart(ele.image,ele.price,ele.title))
    });
}


        function addToCart(img,price){

            arr.push({i:img , p:price});
            console.log(arr);
            // let myCData = [];
            // let d = {img ,price}
            // myCData.push(d);       

            // console.log(myCData);
            alert("product added to cart");
            let cartImgEle  = document.createElement("img");
            let cartTrashbtn = document.createElement("i");
            cartTrashbtn.setAttribute("class","fa-solid fa-trash")
            cartImgEle.setAttribute("src",img);
            cartImgEle.setAttribute("class","cartImgElement");
            
            
            let cartPriceEle = document.createElement("p");
            let cartPriceText=document.createTextNode(price);
            cartPriceEle.appendChild(cartPriceText);
            dynamic_count.innerHTML= arr.length;
        
            renderCartData.appendChild(cartImgEle);//display the image in addtocart list 
            renderCartData.appendChild(cartPriceEle);//display the price in addtocart list
            renderCartData.appendChild(cartTrashbtn);//display the trash icon when the add to cart is clicked
        

        // renderData.appendChild(createImgEle);   
        // appending the images to the page
        // renderData.appendChild(createTitle);
        // renderData.appendChild(btnEle); 
        // renderData.appendChild(createPriceEle); 
    //  function     
    
    
    
    } 


 
//get the data by api
 

getData();  































































