function clearErrors() {
  var errors = document.getElementsByClassName("ferror"); //get ELEMENTS from span class ferror
  for (let item of errors) {
    //for of loop
    item.innerHTML = "";
  }
}

function seterror(id, error) {
  //added function with id and error
  element = document.getElementById(id);
  element.getElementsByClassName("ferror")[0].innerHTML = error;
}

function validateForm() {
  var returnval = true;
  clearErrors();
  var fname = document.forms["myForm"]["ffname"].value;
  if (fname.length == 0) {
    seterror("fname", "<br>*Field Required");
    returnval = false;
    console.log("firstname for name", fname);
  }

  var lname = document.forms["myForm"]["flname"].value;
  if (lname.length == 0) {
    seterror("lname", "<br>*Field Required");
    returnval = false;
    console.log("lastname for name", lname);
  }

  var email = document.forms["myForm"]["femail"].value;
  if (email.length < 4 || !email.includes("@")) {
    seterror("email", "<br>*Required @!!!");
    returnval = false;
    console.log("email for email", email);
  }

  var num = document.forms["myForm"]["fnumber"].value;
  if (num.includes(["A-Z"])) {
    seterror("email", "*Requires number and small letters");
    returnval = false;
    console.log("letter for email", email);
  }
  if (num.length !== 10 || isNaN(num)) {
    seterror("num", "<br>*Phone number should be of 10 digits!");
    returnval = false;
    console.log("number for phone", num);
  }

  var password = document.forms["myForm"]["fpass"].value;
  if (password.length < 6) {
    seterror("pass", "<br>*password should be of atleast 8 digits!!");
    returnval = false;
    console.log("pass for password", password);
  }

  var rpassword = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)/;

  if (!password.match(rpassword)) {
    seterror(
      "pass",
      "<br>*Password must contain at least one uppercase letter,one lowercase letter and one digit!!"
    );
    returnval = false;
    console.log("rPass for pass", password);
  }

  if (returnval) {
    showToast();
  }
  return returnval;

  function showToast() {
    const toast = document.getElementById("toast");
    toast.style.display = block;
    // toastContainer.appendChild(toast);
    // function EditInfo() {
    //   edit_id = id;
    //   usernameTextField.value = userArray[id].name;
    //   addUserBtn.innerText = "Save Changes";
    // }
    // ;

    setTimeout(function (showToast) {
      toast.style.display = "none";
    }, 5000);
  }
}
// document.addEventListener("DOMContentLoaded", function () {
//   const toast = document.getElementById("toast");
//   const showtoaster = document.getElementById("btn");

//   showtoaster.addEventListener("click", function () {
//     showToast();
//   });

// let toastbox = document.getElementById("toastbox");

// function showToast() {
//   let toast = document.createElement("div");
//   toast.classList.add("toast");
//   toast.innerHTML = "Submitted Successfully!";
//   toastbox.appendChild(toast);
// }
// let popup = document.getElementById("popup");
// function openPopup() {
//   popup.classist.add("open-popup");
// }
// function closePopup() {
//   popup.classList.remove("open-popup");
// }

// function myFn() {
//   alert("Submitted successfully!");
// }
