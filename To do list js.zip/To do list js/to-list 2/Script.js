document.addEventListener("DOMContentLoaded", function () {
  const box = document.getElementById("box");
  const list = document.getElementById("list");
  // const btn = document.getElementById("btn");

  //event listner on box element

  box.addEventListener("keypress", function (event) {
    if (event.key === "Enter") {
      event.preventDefault();
      addTask();
    }
  });

  // Add a click event listener for the button
  btn.addEventListener("click", function () {
    addTask();
  });

  //if key === enter
  //get the output eith enter key instead of clicking button

  function addTask() {
    const inputValue = box.value.trim();
    if (inputValue === "") {
      alert("Please add your task..");  
    } else {
      let li = document.createElement("li"); //creating html element
      li.innerHTML = inputValue; //TEXT which added in input box
      // list.appendChild(li); //DISPLAY IN LIST CONTAINER

      let span = document.createElement("span");
      span.innerHTML = "\u00d7";
      // li.appendChild(span);

      let span1 = document.createElement("span");
      span1.innerHTML = '<i class="fas fa-pen-square"></i>';

      // li.appendChild(span1);
      // box.value = "";

      span1.addEventListener("click", function () {
        if (!li.classList.contains("editing")) {
          li.classList.add("editing");
        const editInput = document.createElement("input");
        editInput.type = "text";
        editInput.value = li.textContent.trim();
        li.textContent = "";
        li.appendChild(editInput);
        li.appendChild(span1);

        editInput.addEventListener("blur", function () {
          li.textContent = editInput.value;
          li.removeChild(editInput);

          li.appendChild(span1);
          li.classList.remove("editing");
        
        // li.classList.add("editing");
      });
    }
  });

  li.appendChild(span);
  li.appendChild(span1);

  list.appendChild(li);
  box.value = "";//when the value is added it will be removed from input box
} 
}
});






  

  // const paragraph = document.getElementById("box");
  // const edit_btn = document.getElementById("edit_btn");
  // const end_edit = document.getElementById("end_edit");

  // edit_btn.addEventListener("click", function () {
  //   paragraph.contentEditable = true;
  //   paragraph.style.backgroundColor = "#dddbdb";
  // });

  // end_btn.addEventListener("click", function () {
  //   paragraph.contentEditable = false;
  //   paragraph.style.backgroundColor = "#ffe44d";
  // });

  //

  list.addEventListener("click", function (e) {
    if (e.target.tagName === "LI") {
      //if tagname=li toggle with
      e.target.classList.toggle("checked");
    } else if (e.target.tagName === "SPAN") {
      e.target.parentElement.remove();
      //   list.remove();
    }

});

